package com.example.restaurantapp;

public class test {




    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch(menuItem.getItemId()) {
            case R.id.drinks:

                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            case R.id.nav_gallery:
                Log.i("navigation","gallery clicked");
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            case R.id.nav_share:
                Log.i("navigation","share clicked");
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            default:
                return false;
        }
    }
}
